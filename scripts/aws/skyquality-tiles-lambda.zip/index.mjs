import { PNG } from "pngjs";
import { fromUrl } from "geotiff";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const NATURAL_MCD_M2 = 0.171168465;
const SQM_DENOM = 108000000;
const NODATA_F32 = -3.4028234663852886e38;
const LIGHT_TILE_SIZE = 256;
const MIN_SQM = 16;
const MAX_SQM = 22;

const LIGHT_GRADIENT = [
  { t: 0, color: [30, 170, 95, 70] },
  { t: 0.35, color: [92, 200, 118, 120] },
  { t: 0.55, color: [210, 190, 70, 150] },
  { t: 0.78, color: [245, 155, 65, 190] },
  { t: 1, color: [230, 70, 70, 220] },
];

const BUCKET = process.env.TIF_BUCKET || "vela-s3-bucket";
const KEY = process.env.TIF_KEY || "tifs/World_Atlas_2015.tif";
const SIGNED_URL_TTL_SECONDS = 900;

const s3 = new S3Client({});
let cachedImagePromise = null;
let signedUrlExpiresAt = 0;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
};

function clamp(value, min, max) {
  if (value < min) return min;
  if (value > max) return max;
  return value;
}

function roundTo(value, decimals) {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

function bortleFromSqm(sqm) {
  if (sqm >= 21.99) return "class 1";
  if (sqm >= 21.89) return "class 2";
  if (sqm >= 21.69) return "class 3";
  if (sqm >= 20.49) return "class 4";
  if (sqm >= 19.5) return "class 5";
  if (sqm >= 18.94) return "class 6";
  if (sqm >= 18.38) return "class 7";
  return "class 8-9";
}

function tileToBounds(x, y, z) {
  const n = 2 ** z;
  const lonLeft = (x / n) * 360 - 180;
  const lonRight = ((x + 1) / n) * 360 - 180;
  const mercToLat = (t) =>
    (180 / Math.PI) * Math.atan(0.5 * (Math.exp(t) - Math.exp(-t)));
  const latTop = mercToLat(Math.PI - (2 * Math.PI * y) / n);
  const latBottom = mercToLat(Math.PI - (2 * Math.PI * (y + 1)) / n);
  return {
    minLon: lonLeft,
    maxLon: lonRight,
    minLat: latBottom,
    maxLat: latTop,
  };
}

function boundsIntersect(a, b) {
  return (
    a.minLon < b.maxLon &&
    a.maxLon > b.minLon &&
    a.minLat < b.maxLat &&
    a.maxLat > b.minLat
  );
}

function interpolateGradient(stops, t) {
  if (t <= stops[0].t) return stops[0].color;
  if (t >= stops[stops.length - 1].t) return stops[stops.length - 1].color;
  for (let i = 0; i < stops.length - 1; i++) {
    const a = stops[i];
    const b = stops[i + 1];
    if (t >= a.t && t <= b.t) {
      const span = b.t - a.t || 1;
      const localT = (t - a.t) / span;
      return a.color.map((c, idx) =>
        Math.round(c + (b.color[idx] - c) * localT)
      );
    }
  }
  return stops[stops.length - 1].color;
}

function colorFromArtificial(artificial) {
  if (!Number.isFinite(artificial) || artificial < 0) {
    return [0, 0, 0, 0];
  }

  const total = artificial + NATURAL_MCD_M2;
  if (!Number.isFinite(total) || total <= 0) return [0, 0, 0, 0];

  const sqm = Math.log10(total / SQM_DENOM) / -0.4;
  const clampedSqm = clamp(sqm, MIN_SQM, MAX_SQM);
  const normalized = 1 - (clampedSqm - MIN_SQM) / (MAX_SQM - MIN_SQM);

  return interpolateGradient(LIGHT_GRADIENT, normalized);
}

async function getImage() {
  const now = Date.now();
  if (cachedImagePromise && now < signedUrlExpiresAt - 60_000) {
    return cachedImagePromise;
  }

  const signedUrl = await getSignedUrl(
    s3,
    new GetObjectCommand({ Bucket: BUCKET, Key: KEY }),
    { expiresIn: SIGNED_URL_TTL_SECONDS }
  );

  signedUrlExpiresAt = now + SIGNED_URL_TTL_SECONDS * 1000;

  cachedImagePromise = (async () => {
    const tiff = await fromUrl(signedUrl);
    return await tiff.getImage();
  })().catch((err) => {
    cachedImagePromise = null;
    throw err;
  });

  return cachedImagePromise;
}

function jsonResponse(statusCode, payload) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      ...corsHeaders,
    },
    body: JSON.stringify(payload),
  };
}

function pngResponse(buffer) {
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": "public, max-age=3600",
      ...corsHeaders,
    },
    isBase64Encoded: true,
    body: buffer.toString("base64"),
  };
}

export const handler = async (event) => {
  let rawPath = event.rawPath || event.path || "/";

  // If API Gateway stage is included in the path (e.g. /default/skyquality),
  // remove the first path segment so routes match your code.
  const stage = rawPath.split("/")[1];
  if (stage && rawPath.startsWith(`/${stage}/`)) {
    rawPath = rawPath.slice(stage.length + 1); // removes "/{stage}"
    if (rawPath === "") rawPath = "/";
  }
  const query =
    event.queryStringParameters ||
    Object.fromEntries(new URLSearchParams(event.rawQueryString || ""));

  try {
    if (rawPath === "/skyquality" || rawPath === "/api/skyquality") {
      const lat = Number(query.lat);
      const lon = Number(query.lon);

      if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
        return jsonResponse(400, { error: "Invalid lat/lon query params" });
      }

      const image = await getImage();
      const [minLon, minLat, maxLon, maxLat] = image.getBoundingBox();

      if (lon < minLon || lon > maxLon || lat < minLat || lat > maxLat) {
        return jsonResponse(400, {
          error: "Coordinates out of dataset bounds",
        });
      }

      const width = image.getWidth();
      const height = image.getHeight();
      const xRes = (maxLon - minLon) / width;
      const yRes = (maxLat - minLat) / height;

      let col = Math.floor((lon - minLon) / xRes);
      let row = Math.floor((maxLat - lat) / yRes);

      col = clamp(col, 0, width - 1);
      row = clamp(row, 0, height - 1);

      const rasters = await image.readRasters({
        window: [col, row, col + 1, row + 1],
      });

      const sample = rasters?.[0]?.[0];
      const artificial = Number(sample);

      if (!Number.isFinite(artificial) || artificial === NODATA_F32) {
        return jsonResponse(404, { error: "No data at this coordinate" });
      }

      const total = artificial + NATURAL_MCD_M2;
      const sqm = Math.log10(total / SQM_DENOM) / -0.4;
      const ratio = artificial / NATURAL_MCD_M2;

      return jsonResponse(200, {
        Coordinates: [roundTo(lat, 5), roundTo(lon, 5)],
        SQM: roundTo(sqm, 2),
        Brightness_mcd_m2: roundTo(total, 1),
        Artif_bright_uccd_m2: Math.round(artificial * 1000),
        Ratio: roundTo(ratio, 1),
        Bortle: bortleFromSqm(sqm),
      });
    }

    const tileMatch = rawPath.match(
      /^\/(api\/)?lightmap\/(\d+)\/(\d+)\/(\d+)\.png$/
    );

    if (tileMatch) {
      const z = Number(tileMatch[2]);
      const x = Number(tileMatch[3]);
      const y = Number(tileMatch[4]);

      const image = await getImage();
      const [dataMinLon, dataMinLat, dataMaxLon, dataMaxLat] =
        image.getBoundingBox();

      const tileBounds = tileToBounds(x, y, z);
      const datasetBounds = {
        minLon: dataMinLon,
        maxLon: dataMaxLon,
        minLat: dataMinLat,
        maxLat: dataMaxLat,
      };

      if (!boundsIntersect(tileBounds, datasetBounds)) {
        const empty = new PNG({
          width: LIGHT_TILE_SIZE,
          height: LIGHT_TILE_SIZE,
        });
        return pngResponse(PNG.sync.write(empty));
      }

      const width = image.getWidth();
      const height = image.getHeight();
      const xRes = (dataMaxLon - dataMinLon) / width;
      const yRes = (dataMaxLat - dataMinLat) / height;

      let colStart = Math.floor((tileBounds.minLon - dataMinLon) / xRes);
      let colEnd = Math.ceil((tileBounds.maxLon - dataMinLon) / xRes);
      let rowStart = Math.floor((dataMaxLat - tileBounds.maxLat) / yRes);
      let rowEnd = Math.ceil((dataMaxLat - tileBounds.minLat) / yRes);

      colStart = clamp(colStart, 0, width - 1);
      colEnd = clamp(colEnd, colStart + 1, width);
      rowStart = clamp(rowStart, 0, height - 1);
      rowEnd = clamp(rowEnd, rowStart + 1, height);

      const raster = await image.readRasters({
        window: [colStart, rowStart, colEnd, rowEnd],
        width: LIGHT_TILE_SIZE,
        height: LIGHT_TILE_SIZE,
        samples: [0],
        interleave: true,
        resampleMethod: "bilinear",
      });

      const data = Array.isArray(raster) ? raster[0] : raster;
      if (!data || data.length === 0) {
        const empty = new PNG({
          width: LIGHT_TILE_SIZE,
          height: LIGHT_TILE_SIZE,
        });
        return pngResponse(PNG.sync.write(empty));
      }

      const png = new PNG({ width: LIGHT_TILE_SIZE, height: LIGHT_TILE_SIZE });
      for (let i = 0; i < data.length; i++) {
        const value = data[i];
        const [r, g, b, a] =
          Number.isFinite(value) && value !== NODATA_F32
            ? colorFromArtificial(value)
            : [0, 0, 0, 0];
        const idx = i * 4;
        png.data[idx] = r;
        png.data[idx + 1] = g;
        png.data[idx + 2] = b;
        png.data[idx + 3] = a;
      }

      return pngResponse(PNG.sync.write(png));
    }

    return jsonResponse(404, { error: "Not found" });
  } catch (err) {
    return jsonResponse(500, {
      error: err instanceof Error ? err.message : "Lambda failed",
    });
  }
};
