import json
import math
import os

import ee  # from earthengine-api


# ---------- CONFIG ----------

# Default and max allowed radius (in km)
DEFAULT_RADIUS_KM = 20        # used if searchDistance not provided
MAX_ALLOWED_RADIUS_KM = 100   # if above this -> error

# Grid step and EE sampling scale
GRID_STEP_KM = 4              # spacing between grid points in km
SAMPLE_SCALE_M = 3000         # EE sampling resolution in meters

# Env vars
EE_SERVICE_ACCOUNT = os.getenv("EE_SERVICE_ACCOUNT")
EE_KEY_PATH = os.getenv("EE_KEY_PATH", "/var/task/ee-key.json")

# Datasets
VIIRS_COLLECTION_ID = "NOAA/VIIRS/DNB/MONTHLY_V1/VCMCFG"   # monthly nighttime lights
LAND_WATER_COLLECTION_ID = "MODIS/006/MOD44W"              # land / water mask (0=land, 1=water)


# ---------- EARTH ENGINE INIT (runs on cold start) ----------

def init_ee():
    """
    Initialize Google Earth Engine using the service account and key file.
    This runs once per Lambda cold start.
    """
    if not EE_SERVICE_ACCOUNT:
        raise RuntimeError("EE_SERVICE_ACCOUNT env var not set")
    if not os.path.exists(EE_KEY_PATH):
        raise RuntimeError(f"EE key file not found at {EE_KEY_PATH}")

    creds = ee.ServiceAccountCredentials(EE_SERVICE_ACCOUNT, EE_KEY_PATH)
    ee.Initialize(creds)


# Initialize EE when the Lambda container starts
init_ee()

# Latest VIIRS nighttime-lights image (monthly)
LATEST_VIIRS_IMG = ee.ImageCollection(VIIRS_COLLECTION_ID) \
    .sort("system:time_start", False) \
    .first()

# Land/water mask: MOD44W water_mask band (0 = land, 1 = water)
LAND_WATER = ee.ImageCollection(LAND_WATER_COLLECTION_ID) \
    .select("water_mask") \
    .mosaic()

# Combine brightness + water mask into a single image so we only sample once
COMBINED_IMG = LATEST_VIIRS_IMG.addBands(LAND_WATER)


# ---------- GEO HELPERS ----------

def haversine_km(lat1, lon1, lat2, lon2):
    """Distance between two lat/lon points in km."""
    R = 6371.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def km_to_lat(delta_km):
    """Convert N/S km distance to degrees latitude."""
    return delta_km / 111.32


def km_to_lon(delta_km, lat):
    """Convert E/W km distance to degrees longitude at a given latitude."""
    return delta_km / (111.32 * math.cos(math.radians(lat)))


def light_value_to_level(v):
    """
    Map avg_rad to a simple 1–5 darkness level.
    1 = darkest, 5 = brightest.
    """
    if v < 1:
        return 1
    if v < 5:
        return 2
    if v < 15:
        return 3
    if v < 30:
        return 4
    return 5


# ---------- CORE SEARCH LOGIC (BATCHED EE CALL) ----------

def find_dark_spots(lat, lon, radius_km, step_km=GRID_STEP_KM):
    """
    Build a grid of points around (lat, lon), query light value for all of them
    in ONE Earth Engine call, and return the 3 darkest land spots (no sea).
    radius_km is dynamic per request.
    """
    candidates = []        # Python-side metadata per point
    features = []          # EE Features for sampling

    steps = int(radius_km / step_km)
    idx = 0

    # 1) Build the grid and remember each point with an index
    for i in range(-steps, steps + 1):
        for j in range(-steps, steps + 1):
            dlat_km = i * step_km
            dlon_km = j * step_km

            dlat = km_to_lat(dlat_km)
            dlon = km_to_lon(dlon_km, lat)

            plat = lat + dlat
            plon = lon + dlon

            dist = haversine_km(lat, lon, plat, plon)
            if dist > radius_km:
                continue

            # Store Python-side info
            candidates.append({
                "idx": idx,
                "lat": plat,
                "lon": plon,
                "distance_km": dist,
            })

            # Create an EE Feature with an idx property
            point_geom = ee.Geometry.Point([plon, plat])
            feat = ee.Feature(point_geom, {"idx": idx})
            features.append(feat)

            idx += 1

    if not candidates:
        return []

    # 2) Create a FeatureCollection from all points
    fc = ee.FeatureCollection(features)

    # 3) Sample VIIRS + land/water at ALL points in ONE call
    samples_fc = COMBINED_IMG.sampleRegions(
        collection=fc,
        properties=["idx"],
        scale=SAMPLE_SCALE_M,
        geometries=False,
    )

    samples = samples_fc.getInfo().get("features", [])

    # 4) Build a lookup: idx -> (avg_rad, water_mask)
    values_by_idx = {}
    for f in samples:
        props = f.get("properties", {})
        idx_val = props.get("idx")
        if idx_val is None:
            continue

        try:
            idx_int = int(idx_val)
        except (TypeError, ValueError):
            continue

        avg_rad = props.get("avg_rad")
        water_mask = props.get("water_mask")
        values_by_idx[idx_int] = (avg_rad, water_mask)

    # 5) Merge EE results back into our Python candidates list
    final_candidates = []
    for c in candidates:
        idx_int = c["idx"]
        pair = values_by_idx.get(idx_int)
        if not pair:
            continue

        avg_rad, water_mask = pair

        # Skip water (water_mask == 1) or no data
        if water_mask == 1 or avg_rad is None:
            continue

        c_out = {
            "lat": round(c["lat"], 6),
            "lon": round(c["lon"], 6),
            "distance_km": round(c["distance_km"], 2),
            "light_value": float(avg_rad),
        }
        final_candidates.append(c_out)

    if not final_candidates:
        return []

    # 6) Sort darkest → brightest and take top 3
    final_candidates.sort(key=lambda c: c["light_value"])
    top = final_candidates[:3]

    # 7) Attach darkness levels
    for c in top:
        c["level"] = light_value_to_level(c["light_value"])

    return top


# ---------- LAMBDA HANDLER ----------

def parse_radius(params):
    """
    Read searchDistance from params/body.
    - If missing: return DEFAULT_RADIUS_KM
    - If > MAX_ALLOWED_RADIUS_KM or <= 0: raise ValueError
    """
    raw = (
        params.get("searchDistance")
        or params.get("search_distance")
        or params.get("radius_km")
    )

    if raw is None:
        return DEFAULT_RADIUS_KM

    try:
        radius = float(raw)
    except ValueError:
        raise ValueError("searchDistance must be a number (km)")

    if radius <= 0:
        raise ValueError("searchDistance must be > 0")
    if radius > MAX_ALLOWED_RADIUS_KM:
        raise ValueError(f"searchDistance must be <= {MAX_ALLOWED_RADIUS_KM} km")

    return radius


def lambda_handler(event, context):
    """
    Expect either:
    - API Gateway query params: ?lat=..&lon=..&searchDistance=..
    - or JSON body: { "lat": .., "lon": .., "searchDistance": .. }
    searchDistance is in kilometers.
    """
    try:
        params = event.get("queryStringParameters") or {}
        body = event.get("body")
        if body and isinstance(body, str):
            try:
                body_json = json.loads(body)
                params.update(body_json)
            except Exception:
                pass

        lat = float(params.get("lat"))
        lon = float(params.get("lon"))
        radius_km = parse_radius(params)

    except ValueError as ve:
        # for bad radius or bad number conversions
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "BadRequest", "details": str(ve)}),
        }
    except Exception as e:
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Missing or invalid lat/lon", "details": str(e)}),
        }

    try:
        spots = find_dark_spots(lat, lon, radius_km)
        response = {
            "origin": {"lat": lat, "lon": lon},
            "radius_km": radius_km,
            "spots": spots,
        }
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(response),
        }
    except Exception as e:
        # helpful if something goes wrong
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "INTERNAL_ERROR", "details": str(e)}),
        }
